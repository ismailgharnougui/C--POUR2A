#ifndef APPLICATION_H_INCLUDED
#define APPLICATION_H_INCLUDED

#include<vector>
using namespace std;
#include"abonnement.h"
#include"Parking.h"

class Application
{
private:
    vector <Parking> tab_park;
    vector <Carte*> tab_carte; // !!!

public:
    Application (){}
    Application (Application &);
    Application operator= (Application & App);
    ~Application ();

    bool ajouter_parking(const Parking&);
    vector<Parking>::iterator rechercherP(long);
    vector<Carte*>::iterator rechercherC(long);

    bool ajouter_carte(const Carte&);
    void ajouter_carte(const Abonnemet&);

    bool ajouter_ID (long ID);
    void afficher();
    Parking& moin_rentable();
    vector<Parking>::iterator moin_rentable2();
    bool supprimer(long id);
    //void save();


};


#endif // APPLICATION_H_INCLUDED
