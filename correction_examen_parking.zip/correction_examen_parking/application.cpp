#include"application.h"
#include<iostream>
#include <typeinfo>

Application::Application (Application & App)
{
    vector<Carte*>::iterator it;

    Carte* p;

    for(it=App.tab_carte.begin();it!=App.tab_carte.end();it++)
    {
        if (typeid (**it)==typeid (Carte))
        {
            p =  new Carte (**it);
        }
        else
        {
            p =  new Abonnemet (static_cast <Abonnemet &> (**it));
            //p =  new Abonnemet ((Abonnemet&) (**it));
        }
        tab_carte.push_back(p);

    }
}
Application::~Application ()
{
    vector<Carte*>::iterator it;

    for(it=tab_carte.begin();it!=tab_carte.end();it++)
        delete *it;
}

Application Application::operator= (Application & App)
{
    if (this != &App)
    {
        vector<Carte*>::iterator it;

        for(it=tab_carte.begin();it!=tab_carte.end();it++)
            delete *it;

        tab_carte.clear();

        Carte* p;

        for(it=App.tab_carte.begin();it!=App.tab_carte.end();it++)
        {
            if (typeid (**it)==typeid (Carte))
            {
                p =  new Carte (**it);
            }
            else
            {
                p =  new Abonnemet (static_cast <Abonnemet &> (**it));
                //p =  new Abonnemet ((Abonnemet&) (**it));
            }
            tab_carte.push_back(p);

        }
    }
    return *this;
}


bool Application::ajouter_ID(long id)
{
    vector<Parking> ::iterator i;
    for(i=tab_park.begin();i!=tab_park.end();i++)
    {
        if(i->id_autorise(id))
        {
            if(i->nbr_place()<i->get_place_t())
            {
                if(!(i->id_utilise(id)))
                {
                    i->ajouter_ID_util(id);
                    return true;
                }
                else
                {
                    cout<<"carte utilis�"<<endl;
                    return false;
                }

            }
            else
            {
                cout<<"ya pas de place"<<endl;
                return false;
            }

        }
        else
           {
            cout<<"non autoris�"<<endl;
            return false;}
    }
    return false;
}

Parking& Application::moin_rentable()
{
    vector<Parking> ::iterator i;
    i=tab_park.begin();
   double moin=i->taux_remplissage();

    for(i=tab_park.begin()+1;i!=tab_park.end();i++)
    {
        if (i->taux_remplissage()<moin)
            moin = i->taux_remplissage();
    }
    return *i;
}

vector<Parking>::iterator Application::moin_rentable2()
{
    vector<Parking> ::iterator i;
    i=tab_park.begin();
   double moin=i->taux_remplissage();

    for(i=tab_park.begin()+1;i!=tab_park.end();i++)
    {
        if (i->taux_remplissage()<moin)
            moin = i->taux_remplissage();
    }
    return i;
}

bool Application::supprimer(long id)
{
    vector<Parking> ::iterator i;

    for(i=tab_park.begin();i!=tab_park.end();i++)
    {
        if(i->id_autorise(id))
        {
            if (i->id_utilise(id))
            {
                i->supprimer_id(id);
                return true;
            }
            else return false;

        }
        else return false;
    }
    return false;
}
vector<Parking>::iterator Application::rechercherP(long r)
{
    vector<Parking>::iterator it;
    for(it=tab_park.begin();it!=tab_park.end();it++)
    {
        if(it->get_ref()==r)
            return it;
    }
    return tab_park.end();
}

vector<Carte*>::iterator Application::rechercherC(long id)
{
    vector<Carte*>::iterator it;
    for(it=tab_carte.begin();it!=tab_carte.end();it++)
    {
        if((*it)->get_ID()==id)
            return it;
    }
    return tab_carte.end();
}

bool Application::ajouter_parking(const Parking& P)
{
    vector<Parking>::iterator it=rechercherP(P.get_ref());

    if(it==tab_park.end())
    {
        tab_park.push_back(P);
        return true;
    }
    else return false;
}

bool Application::ajouter_carte(const Carte& C)
{
    vector<Carte*>::iterator it=rechercherC(C.get_ID());
    if(it==tab_carte.end())
    {
        Carte* p=new Carte(C);
        tab_carte.push_back(p);
        return true;
    }
    else return false;
}

void Application::ajouter_carte(const Abonnemet& A)
{
    vector<Carte*>::iterator it=rechercherC(A.get_ID());
    try
    {
        if(it==tab_carte.end())
        {
        Carte* p=new Abonnemet(A);
        tab_carte.push_back(p);
        }
        else
            throw string ("la carte existe d�j�\n");

    }
    catch (string const& ch)
    {
        cerr<<ch<<endl;
    }

}

void Application::afficher()
{
    vector<Parking>::iterator it;
    for(it=tab_park.begin();it!=tab_park.end();it++)
    {
        it->afficher();
    }
    vector<Carte*>::iterator i;
    for(i=tab_carte.begin();i!=tab_carte.end();i++)
    {
        (*i)->afficher();
    }
}
