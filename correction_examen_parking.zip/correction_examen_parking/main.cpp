#include <iostream>
#include"Parking.h"
#include"application.h"

using namespace std;

int main()
{
    /*Carte c1;
    c1.saisie();*/

    Carte c(12,"9h",3,1500);

    Abonnemet A(22,"10h",6,0,"2017",2);
    Abonnemet A1(22,"10h",6,0,"2017",2);

    Parking P(11,30);
    Parking P1(001,10);

    Application App;

    App.ajouter_carte(c);
    App.ajouter_carte(A);

    App.ajouter_carte(A1);
    App.ajouter_parking(P);
    App.ajouter_parking(P1);
    App.afficher();

    Parking& px = App.moin_rentable();
    vector<Parking>::iterator it =  App.moin_rentable2();

    Application App2 (App); //bug -> cons copy

    return 0;
}
