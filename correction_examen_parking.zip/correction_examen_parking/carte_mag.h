#ifndef CARTE_MAG_H_INCLUDED
#define CARTE_MAG_H_INCLUDED
#include<string>
using namespace std;

class Carte
{
    protected:
    long id;
    string date_heur_entre;
    int nbr_heure;
    double prix_heure;
    public:
//        carte(){}
        Carte(long ,string ,int , double );

        virtual ~Carte(){}
        virtual void afficher();
        long get_ID()const{return id;}
      //  virtual double calculer_prix(){return (prix_heure*nbr_heure);};
};

#endif // CARTE_MAG_H_INCLUDED
