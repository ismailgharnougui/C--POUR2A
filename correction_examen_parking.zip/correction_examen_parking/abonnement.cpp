#include <iostream>
#include"abonnement.h"

Abonnemet::Abonnemet(long ide, string d_h_e,int nb_h,double p_h,string d_ex,int g):Carte(ide,d_h_e,nb_h,p_h)
{
    date_expedition=d_ex;
    gratuite=g;

}
void Abonnemet::afficher()
{
    Carte::afficher();
    cout<<"date dexpedition  "<<date_expedition<<endl;
    cout<<"gratuite   "<<gratuite<<endl;
}
