#ifndef ABONNEMENT_H_INCLUDED
#define ABONNEMENT_H_INCLUDED
#include"carte_mag.h"

class Abonnemet: public Carte
{
private:
    string date_expedition;
    int gratuite;
public:
    Abonnemet(long id=0,string date_heur_entre=" ",int nbr_heure=0, double prix_heure=0.0,string date_expedition=" ",int gratuite=0);
    void afficher ();
  //  double calculer_prix() {return (nbr_heure-10)*prix_heure;}
    ~Abonnemet(){}

};

#endif // ABONNEMENT_H_INCLUDED
