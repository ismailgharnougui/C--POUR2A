#include"application.h"
#include<iostream>
bool Application::ajouter_ID(long id)
{
    vector<Parking> ::iterator i;
    for(i=tab_park.begin();i!=tab_park.end();i++)
    {
        if(i->id_autorise(id))
        {
            if(i->nbr_place()<i->get_place_t())
            {
                if(!(i->id_utilise(id)))
                {
                    i->ajouter_ID_util(id);
                    return true;
                }
                else
                {
                    cout<<"carte utilis�"<<endl;
                    return false;
                }

            }
            else
            {
                cout<<"ya pas de place"<<endl;
                return false;
            }

        }
        else
           {
            cout<<"non autoris�"<<endl;
            return false;}
    }
    return false;
}
Parking Application::moin_rentable()
{ vector<Parking> ::iterator i;
    i=tab_park.begin();
   double moin=i->taux_remplissage();

    for(i=tab_park.begin()+1;i!=tab_park.end();i++)
    {
        if (i->taux_remplissage()<moin)
            moin=i->taux_remplissage();
    }
    return *i;
}


bool Application::supprimer(long id)
{
    vector<Parking> ::iterator i;

    for(i=tab_park.begin();i!=tab_park.end();i++)
    {
        if(i->id_autorise(id))
        {
            if (i->id_utilise(id))
            {
                i->supprimer_id(id);
                return true;
            }
            else return false;

        }
        else return false;
    }
    return false;
}
