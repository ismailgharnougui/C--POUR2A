#ifndef PARKING_H_INCLUDED
#define PARKING_H_INCLUDED
#include <vector>
using namespace std;

class Parking
{
private:
    long refer;
    int nb_place_t;
    vector<long> tab_id_aut;
    vector<long> tab_id_uti;
public:

    Parking(long refer=0, int nb_place_t=0);
    ~Parking(){}
    void afficher(){}
    long get_ref(){return refer;}
    int get_place_t(){return nb_place_t;}
    void ajouter_ID_aut(long);
    void ajouter_ID_util(long);
    bool id_autorise(long);
    bool id_utilise(long);
    int nbr_place(){return tab_id_uti.size();}
    double taux_remplissage (){return (tab_id_uti.size()/nb_place_t);}
    bool supprimer_id(long);



};

#endif // PARKING_H_INCLUDED
