#include <iostream>
#include"carte_mag.h"

Carte::Carte(long ide, string d_h_e,int nb_h,double p_h):id(ide),date_heur_entre(d_h_e),nbr_heure(nb_h),prix_heure(p_h)
{
}

void Carte::afficher()
{
    cout<<"l'id est: "<<id<<endl;
    cout<<"date et heure d'entree: "<<date_heur_entre<<endl;
    cout<<"le nombre d'heure est: "<<nbr_heure<<endl;
    cout <<"prix d'heure est: "<<prix_heure<<endl;

}

