#include"abonnement.h"
#include"Parking.h"

Parking::Parking(long r,int p_total):refer(r),nb_place_t(p_total)
{

}
bool Parking:: id_autorise(long id)
{
    vector<long> ::iterator i;
    for(i=tab_id_aut.begin();i!=tab_id_aut.end();i++)
    {
        if (*i==id)
            return true;
    }
    return false;
}

bool Parking:: id_utilise(long id)
{
    vector<long> ::iterator i;
    for(i=tab_id_uti.begin();i!=tab_id_uti.end();i++)
    {
        if (*i==id)
            return true;
    }
    return false;
}

void Parking::ajouter_ID_aut(long id)
{
    if(id_autorise(id)==false)
        tab_id_aut.push_back(id);
}
void Parking::ajouter_ID_util(long id)
{
    if(id_utilise(id)==false)
        tab_id_uti.push_back(id);
}
bool Parking::supprimer_id(long id)
{
    vector<long>::iterator i;
    for(i=tab_id_aut.begin();i!=tab_id_aut.end();i++)
    {
        if (*i==id)
        {
            tab_id_aut.erase(i);
            return true;
        }
    }

    vector<long>::iterator j;
    for(j=tab_id_uti.begin();j!=tab_id_uti.end();j++)
    {
        if (*j==id)
        {
            tab_id_uti.erase(j);
            return true;
        }
    }

return false;

}
