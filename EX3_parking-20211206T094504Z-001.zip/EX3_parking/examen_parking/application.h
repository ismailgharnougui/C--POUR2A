#ifndef APPLICATION_H_INCLUDED
#define APPLICATION_H_INCLUDED

#include<vector>
using namespace std;
#include"abonnement.h"
#include"Parking.h"

class Application
{
private:
    vector<Parking> tab_park;
    vector<Carte*> tab_carte;

public:
    bool ajouter_parking(const Parking&);
    bool ajouter_carte(const Carte&);
    bool ajouter_carte(const Abonnemet&);
    bool ajouter_ID (long ID);
    Parking moin_rentable();
    bool supprimer(long id);


};


#endif // APPLICATION_H_INCLUDED
